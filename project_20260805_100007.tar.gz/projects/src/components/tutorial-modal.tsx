'use client';

import { useState } from 'react';
import { TUTORIAL_STEPS } from '@/lib/constants';

interface TutorialModalProps {
  onClose: () => void;
}

export function TutorialModal({ onClose }: TutorialModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const totalSteps = TUTORIAL_STEPS.length;

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const step = TUTORIAL_STEPS[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--background)] rounded-2xl shadow-xl p-6 mx-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-[var(--foreground)]">使用教程</h2>
          <span className="text-sm text-[var(--muted-foreground)]">
            {currentStep + 1} / {totalSteps}
          </span>
        </div>

        {/* Progress dots */}
        <div className="flex gap-1.5 mb-6">
          {TUTORIAL_STEPS.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 flex-1 rounded-full transition-colors ${
                i <= currentStep ? 'bg-[var(--primary)]' : 'bg-[var(--border)]'
              }`}
            />
          ))}
        </div>

        {/* Step content */}
        <div className="text-center mb-6">
          <div className="text-5xl mb-4">{step.icon}</div>
          <h3 className="text-xl font-bold text-[var(--foreground)] mb-2">{step.title}</h3>
          <p className="text-base text-[var(--muted-foreground)] leading-relaxed">{step.desc}</p>
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          {currentStep > 0 && (
            <button
              onClick={handlePrev}
              className="flex-1 py-3 rounded-xl border border-[var(--border)] text-[var(--foreground)] text-base font-medium hover:bg-[var(--muted)] transition-colors"
            >
              上一步
            </button>
          )}
          <button
            onClick={handleNext}
            className="flex-1 py-3 rounded-xl bg-[var(--primary)] text-white text-base font-medium hover:opacity-90 transition-colors"
          >
            {currentStep < totalSteps - 1 ? '下一步' : '开始使用'}
          </button>
        </div>

        {/* Skip */}
        <button
          onClick={onClose}
          className="w-full mt-3 py-2 text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors"
        >
          跳过教程
        </button>
      </div>
    </div>
  );
}
