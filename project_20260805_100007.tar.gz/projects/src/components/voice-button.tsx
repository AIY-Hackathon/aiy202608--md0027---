'use client';

import { useState, useRef, useCallback, useEffect } from 'react';

interface VoiceButtonProps {
  onResult: (text: string) => void;
  onRecordingChange: (recording: boolean) => void;
  speechLang?: string;
}

// Extend Window for webkit prefix
interface SpeechRecognitionEvent {
  results: Array<{
    0: { transcript: string };
    isFinal: boolean;
  }>;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent {
  error: string;
}

interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
  }
}

export function VoiceButton({ onResult, onRecordingChange, speechLang = 'zh-CN' }: VoiceButtonProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const finalTranscriptRef = useRef('');
  const useFallbackRef = useRef(false);

  // Check support after mount to avoid hydration mismatch
  useEffect(() => {
    const supported = !!window.SpeechRecognition || !!window.webkitSpeechRecognition;
    setIsSupported(supported);
  }, []);

  // Update language when it changes
  useEffect(() => {
    if (recognitionRef.current) {
      recognitionRef.current.lang = speechLang;
    }
  }, [speechLang]);

  // Fallback: MediaRecorder + ASR API
  const startFallbackRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Try ogg/opus first, fall back to webm
      let mimeType = 'audio/webm';
      if (MediaRecorder.isTypeSupported('audio/ogg;codecs=opus')) {
        mimeType = 'audio/ogg;codecs=opus';
      } else if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
        mimeType = 'audio/webm;codecs=opus';
      }

      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
        
        const audioBlob = new Blob(chunks, { type: mimeType });
        
        if (audioBlob.size === 0) {
          setIsRecording(false);
          onRecordingChange(false);
          return;
        }

        setIsProcessing(true);
        
        try {
          // Send to ASR API
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64 = (reader.result as string).split(',')[1];
            
            try {
              const response = await fetch('/api/asr', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ audio: base64, format: mimeType.includes('ogg') ? 'ogg_opus' : 'webm' }),
              });
              
              if (response.ok) {
                const data = await response.json();
                if (data.text) {
                  onResult(data.text);
                } else {
                  alert('未能识别语音内容，请重试');
                }
              } else {
                alert('语音识别服务暂时不可用');
              }
            } catch {
              alert('语音识别请求失败');
            } finally {
              setIsProcessing(false);
              setIsRecording(false);
              onRecordingChange(false);
            }
          };
          reader.readAsDataURL(audioBlob);
        } catch {
          setIsProcessing(false);
          setIsRecording(false);
          onRecordingChange(false);
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
      onRecordingChange(true);
      useFallbackRef.current = true;
    } catch (err) {
      console.error('Failed to start recording:', err);
      alert('无法访问麦克风，请检查浏览器权限设置');
      setIsRecording(false);
      onRecordingChange(false);
    }
  }, [onResult, onRecordingChange]);

  const stopFallbackRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current = null;
    }
  }, []);

  // Web Speech API method
  const startSpeechRecognition = useCallback(() => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      // Fall back to MediaRecorder
      startFallbackRecording();
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = speechLang;

    finalTranscriptRef.current = '';
    useFallbackRef.current = false;

    recognition.onstart = () => {
      setIsRecording(true);
      onRecordingChange(true);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalTranscriptRef.current += event.results[i][0].transcript;
        }
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      // If Web Speech API fails, try fallback
      if (event.error === 'network' || event.error === 'service-not-allowed') {
        recognition.abort();
        startFallbackRecording();
        return;
      }
      if (event.error === 'not-allowed') {
        alert('需要麦克风权限才能使用语音功能，请在浏览器设置中允许使用麦克风。');
      }
      setIsRecording(false);
      onRecordingChange(false);
    };

    recognition.onend = () => {
      // Only process if we were using Web Speech API (not fallback)
      if (!useFallbackRef.current) {
        setIsRecording(false);
        onRecordingChange(false);
        const text = finalTranscriptRef.current.trim();
        if (text) {
          onResult(text);
        }
      }
    };

    recognitionRef.current = recognition;
    
    try {
      recognition.start();
    } catch {
      // If start fails, try fallback
      startFallbackRecording();
    }
  }, [speechLang, onResult, onRecordingChange, startFallbackRecording]);

  const stopSpeechRecognition = useCallback(() => {
    if (useFallbackRef.current) {
      stopFallbackRecording();
    } else if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
  }, [stopFallbackRecording]);

  const toggleRecording = () => {
    if (isRecording) {
      stopSpeechRecognition();
    } else {
      startSpeechRecognition();
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  return (
    <button
      onClick={toggleRecording}
      disabled={isProcessing}
      className={`flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-md ${
        isRecording
          ? 'bg-red-500 text-white voice-recording'
          : isProcessing
          ? 'bg-[var(--muted)] text-[var(--muted-foreground)] cursor-wait'
          : 'bg-[var(--accent)] text-white hover:opacity-90 active:scale-95'
      }`}
      title={isRecording ? '点击结束录音' : '点击开始语音输入'}
    >
      {isRecording ? (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
        </svg>
      ) : (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        </svg>
      )}
    </button>
  );
}
