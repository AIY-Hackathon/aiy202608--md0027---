'use client';

import { DIALECTS, LANGUAGES, VOICES } from '@/lib/constants';
import type { AppSettings } from '@/lib/types';

interface SettingsPanelProps {
  settings: AppSettings;
  onChange: (settings: AppSettings) => void;
  onClose: () => void;
}

const FONT_SIZE_OPTIONS = [
  { value: 16, label: '小', desc: '标准字号' },
  { value: 18, label: '中', desc: '推荐字号' },
  { value: 20, label: '大', desc: '舒适阅读' },
  { value: 22, label: '特大', desc: '超大字号' },
];

export function SettingsPanel({ settings, onChange, onClose }: SettingsPanelProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative w-full max-w-md bg-[var(--background)] rounded-t-2xl sm:rounded-2xl shadow-xl p-6 space-y-6 max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-[var(--foreground)]">设置</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Font Size */}
        <div className="space-y-3">
          <label className="text-base font-medium text-[var(--foreground)]">字体大小</label>
          <p className="text-sm text-[var(--muted-foreground)]">调整聊天文字的显示大小</p>
          <div className="grid grid-cols-4 gap-2">
            {FONT_SIZE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => onChange({ ...settings, fontSize: opt.value })}
                className={`px-2 py-3 rounded-xl text-center transition-all ${
                  settings.fontSize === opt.value
                    ? 'bg-[var(--primary)] text-white shadow-md'
                    : 'bg-white border border-[var(--border)] text-[var(--foreground)] hover:border-[var(--primary)]/30'
                }`}
              >
                <span className="text-base font-medium block">{opt.label}</span>
                <span className={`text-xs block mt-0.5 ${settings.fontSize === opt.value ? 'text-white/80' : 'text-[var(--muted-foreground)]'}`}>
                  {opt.value}px
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Voice */}
        <div className="space-y-3">
          <label className="text-base font-medium text-[var(--foreground)]">声音选择</label>
          <p className="text-sm text-[var(--muted-foreground)]">选择声伴说话的声音</p>
          <div className="grid grid-cols-2 gap-2">
            {VOICES.map((v) => (
              <button
                key={v.value}
                onClick={() => onChange({ ...settings, voice: v.value })}
                className={`px-3 py-3 rounded-xl text-left transition-all ${
                  settings.voice === v.value
                    ? 'bg-[var(--primary)] text-white shadow-md'
                    : 'bg-white border border-[var(--border)] text-[var(--foreground)] hover:border-[var(--primary)]/30'
                }`}
              >
                <span className="text-base font-medium block">{v.label}</span>
                <span className={`text-xs block mt-0.5 ${settings.voice === v.value ? 'text-white/80' : 'text-[var(--muted-foreground)]'}`}>
                  {v.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Dialect */}
        <div className="space-y-3">
          <label className="text-base font-medium text-[var(--foreground)]">方言选择</label>
          <p className="text-sm text-[var(--muted-foreground)]">选择后，声伴会用对应的方言风格跟您聊天，语音输入也会识别对应方言</p>
          <div className="grid grid-cols-2 gap-2">
            {DIALECTS.map((d) => (
              <button
                key={d.value}
                onClick={() => onChange({ ...settings, dialect: d.value })}
                className={`px-4 py-3 rounded-xl text-base transition-all ${
                  settings.dialect === d.value
                    ? 'bg-[var(--primary)] text-white shadow-md'
                    : 'bg-white border border-[var(--border)] text-[var(--foreground)] hover:border-[var(--primary)]/30'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </div>

        {/* Language */}
        <div className="space-y-3">
          <label className="text-base font-medium text-[var(--foreground)]">显示语言</label>
          <p className="text-sm text-[var(--muted-foreground)]">翻译声伴的回复为其他语言</p>
          <div className="flex flex-wrap gap-2">
            {LANGUAGES.map((l) => (
              <button
                key={l.value}
                onClick={() => onChange({ ...settings, language: l.value })}
                className={`px-4 py-2.5 rounded-xl text-base transition-all ${
                  settings.language === l.value
                    ? 'bg-[var(--accent)] text-white shadow-md'
                    : 'bg-white border border-[var(--border)] text-[var(--foreground)] hover:border-[var(--accent)]/30'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
