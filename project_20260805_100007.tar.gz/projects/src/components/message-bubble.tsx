'use client';

import { useState } from 'react';
import type { Message } from '@/lib/types';

interface MessageBubbleProps {
  message: Message;
  onPlayAudio: (url: string) => void;
  fontSize?: number;
}

export function MessageBubble({ message, onPlayAudio, fontSize = 18 }: MessageBubbleProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPlayingTranslated, setIsPlayingTranslated] = useState(false);
  const isUser = message.role === 'user';

  const handlePlayAudio = () => {
    if (message.audioUrl) {
      setIsPlaying(true);
      onPlayAudio(message.audioUrl!);
    }
  };

  const handlePlayTranslated = () => {
    if (message.translatedAudioUrl) {
      setIsPlayingTranslated(true);
      onPlayAudio(message.translatedAudioUrl!);
    }
  };

  // Callback when audio finishes
  const handleAudioEnded = () => {
    setIsPlaying(false);
    setIsPlayingTranslated(false);
  };

  // Register audio ended callback via ref-like pattern
  if (typeof window !== 'undefined') {
    const audio = document.querySelector('audio');
    if (audio) {
      audio.onended = handleAudioEnded;
    }
  }

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-5 py-3 shadow-sm ${
          isUser
            ? 'bg-[var(--primary)] text-white rounded-br-md'
            : 'bg-white border border-[var(--border)] text-[var(--foreground)] rounded-bl-md'
        }`}
      >
        {/* Avatar for assistant */}
        {!isUser && (
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-full bg-[var(--primary)]/10 flex items-center justify-center">
              <svg className="w-4 h-4 text-[var(--primary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <span className="text-sm text-[var(--muted-foreground)]">声伴</span>
          </div>
        )}

        {/* Message content */}
        <p style={{ fontSize: `${fontSize}px`, lineHeight: 1.8 }} className="whitespace-pre-wrap">{message.content}</p>

        {/* Audio play button for assistant */}
        {!isUser && message.audioUrl && (
          <button
            onClick={handlePlayAudio}
            className={`mt-2 flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition-colors ${
              isUser
                ? 'text-white/80 hover:text-white text-sm'
                : 'text-[var(--primary)] hover:bg-[var(--primary)]/10'
            }`}
            style={{ fontSize: `${Math.max(fontSize - 4, 14)}px` }}
          >
            {isPlaying ? (
              <svg className="w-4 h-4 animate-pulse" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
              </svg>
            )}
            <span>{isPlaying ? '播放中...' : '播放语音'}</span>
          </button>
        )}

        {/* Translated content */}
        {message.translatedContent && (
          <div className="mt-3 pt-3 border-t border-[var(--border)]/50">
            <div className="flex items-center gap-1.5 mb-1">
              <svg className="w-3.5 h-3.5 text-[var(--muted-foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
              </svg>
              <span className="text-xs text-[var(--muted-foreground)]">翻译</span>
            </div>
            <p style={{ fontSize: `${Math.max(fontSize - 2, 14)}px`, lineHeight: 1.6 }} className="text-[var(--muted-foreground)] whitespace-pre-wrap">
              {message.translatedContent}
            </p>
            {/* Translated audio play */}
            {message.translatedAudioUrl && (
              <button
                onClick={handlePlayTranslated}
                className="mt-1.5 flex items-center gap-1.5 text-sm text-[var(--accent)] hover:bg-[var(--accent)]/10 rounded-lg px-3 py-1.5 transition-colors"
              >
                {isPlayingTranslated ? (
                  <svg className="w-4 h-4 animate-pulse" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                  </svg>
                )}
                <span>{isPlayingTranslated ? '播放中...' : '播放翻译语音'}</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
