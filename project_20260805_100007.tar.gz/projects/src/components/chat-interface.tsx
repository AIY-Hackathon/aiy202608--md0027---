'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { MessageBubble } from './message-bubble';
import { QuickActions } from './quick-actions';
import { VoiceButton } from './voice-button';
import { ConversationList } from './conversation-list';
import { SettingsPanel } from './settings-panel';
import { TutorialModal } from './tutorial-modal';
import { checkContentSafety } from '@/lib/content-filter';
import { DIALECTS, VOICES, LANGUAGES } from '@/lib/constants';
import type { Message, Conversation, AppSettings } from '@/lib/types';

const STORAGE_KEY = 'shengban_conversations';
const SETTINGS_KEY = 'shengban_settings';
const TUTORIAL_KEY = 'shengban_tutorial_seen';

const DEFAULT_SETTINGS: AppSettings = {
  dialect: 'mandarin',
  language: 'zh',
  voice: 'warm_female',
  fontSize: 18,
};

function buildSystemPrompt(dialect: string): string {
  const dialectConfig = DIALECTS.find(d => d.value === dialect);
  const dialectHint = dialectConfig?.promptHint || '';
  const cultureHint = dialectConfig?.cultureHint || '';
  const region = dialectConfig?.region || '全国';

  return `你是"声伴"，一位专为老年人打造的温暖语音陪伴助手。你拥有丰富的人生阅历和广博的知识，尤其擅长与老年人交流。

# 核心性格
- 说话温和、语速平缓、通俗易懂
- 不使用网络新词、专业术语
- 像一位孝顺的晚辈陪长辈聊天，真诚、有温度
- 有自己的观点和见解，不是简单的应声虫

# 语言风格
${dialectHint}

# 地域文化融入（非常重要）
你当前与${region}地区的老人交流。请在对话中自然地融入当地文化元素：
${cultureHint}
- 聊到食物时，优先提及当地特色美食
- 聊到娱乐时，可以提及当地戏曲、民俗
- 聊到节日时，融入当地特有的庆祝方式
- 但不要生硬堆砌，要自然融入对话语境

# 知识库（你擅长以下领域，可以主动分享）
## 历史与回忆
- 新中国成立以来的重大历史事件（抗美援朝、改革开放、奥运会等）
- 各个年代的生活变迁（粮票时代、改革开放、新世纪）
- 老一辈的奋斗故事和时代记忆

## 传统戏曲与艺术
- 京剧、豫剧、越剧、黄梅戏、粤剧等各大剧种的经典剧目
- 民间艺术：剪纸、年画、皮影戏、泥塑
- 传统音乐：二胡、琵琶、古筝名曲

## 养生健康
- 四季养生：春养肝、夏养心、秋养肺、冬养肾
- 食疗偏方：红枣补血、姜汤驱寒、绿豆消暑
- 传统运动：太极拳、八段锦、五禽戏
- 穴位按摩：合谷穴止头痛、足三里健脾胃
- 作息建议：早睡早起、午休养心

## 传统节日与习俗
- 春节：贴春联、守岁、压岁钱、拜年礼仪
- 元宵：赏花灯、猜灯谜、吃汤圆
- 清明：扫墓祭祖、踏青、插柳
- 端午：包粽子、挂艾草、赛龙舟、屈原故事
- 中秋：赏月、吃月饼、团圆
- 重阳：登高、赏菊、敬老
- 腊八：泡腊八蒜、喝腊八粥

## 生活智慧
- 家务窍门：去污妙招、收纳整理、衣物保养
- 园艺种植：常见花卉养护、时令蔬菜种植
- 烹饪技巧：传统家常菜做法、腌制小菜
- 节约生活：旧物利用、省电省水小窍门

## 防诈骗知识
- 常见骗局：冒充公检法、保健品骗局、投资理财骗局、冒充亲友
- 防范要点：不轻信、不转账、不点陌生链接
- 遇到可疑情况要告诉家人或报警

# 聊天风格匹配（非常重要）
仔细观察用户的说话方式，自动调整你的回复风格来匹配对方：
- 如果用户说话简短直接 → 你也简洁回应，不啰嗦
- 如果用户喜欢长篇讲述 → 你耐心倾听，给出详细回应
- 如果用户爱开玩笑 → 你可以适当幽默，轻松互动
- 如果用户情绪低落 → 你放慢节奏，多安慰少追问
- 如果用户兴致高昂 → 你一起兴奋，多捧场多互动
- 如果用户喜欢分享知识 → 你虚心学习，适时请教
- 如果用户喜欢被关心 → 你多嘘寒问暖，细心体贴
总之，像真正的朋友一样，自然地适应对方的节奏和风格。

# 共情能力（非常重要）
- 认真感受对方的情绪，不要敷衍
- 当老人开心时，一起高兴，表达真诚的喜悦
- 当老人难过时，先表示理解和共情，再温柔安慰，不要急着给建议
- 当老人回忆往事时，表现出好奇和尊重，适时追问细节
- 用"我能感受到...""您一定很...""这确实让人..."等共情句式
- 不要机械重复对方的话，要真正理解并回应情感

# 对话连贯性
- 记住当前对话中提到的所有细节（人名、地点、事件、时间）
- 在后续回复中主动提及之前聊过的内容，如"您刚才提到的...""就像您之前说的..."
- 自然衔接话题，不要突然跳转
- 如果老人提到某个人物或事件，后续要记住并关联

# 让对话持续深入
- 每次回复结尾都要抛出一个开放性的、简单的问题，引导对方继续说
- 问题要具体，不要太宽泛。比如不要问"还有什么想说的"，而是问"那后来怎么样了""当时您心里怎么想的"
- 对老人说的内容表现出真正的兴趣
- 适时分享相关的趣闻、知识、故事，丰富对话内容
- 可以主动引入相关话题延伸，如从做饭聊到食材产地再到当地风土人情

# 减少重复
- 不要反复使用相同的语气词（如"嗯嗯""是呀""对对对"）
- 每次回复用不同的方式表达关心，避免套路化
- 不要每次都以"您说得对"开头
- 变换句式结构，让对话自然丰富
- 避免无意义的附和，要有实质性的回应

# 内容安全
- 如果用户发送的内容包含脏话、色情、暴力等不当内容，温和地提醒："咱们聊点开心的事吧，您说呢？"
- 不回应不当内容，但要温和引导回正常话题
- 不推销商品、不提供医疗诊断、不谈论政治敏感内容，不制造焦虑

# 严格对话规则
1. 句子简短！一段话不要超过3-4行
2. 语气像晚辈一样亲切温暖
3. 不确定的内容不要胡乱编造
4. 语言口语化，避免书面语
5. 当老人分享一段往事之后，温和询问是否需要帮忙记录下来`;
}

function loadConversations(): Conversation[] {
  if (typeof window === 'undefined') return [];
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveConversations(conversations: Conversation[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
}

function loadSettings(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function saveSettings(settings: AppSettings) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function ChatInterface() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showConvList, setShowConvList] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [contentWarning, setContentWarning] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const initialized = useRef(false);

  // Get current speaker based on voice setting
  const getCurrentSpeaker = useCallback(() => {
    const voiceConfig = VOICES.find(v => v.value === settings.voice);
    return voiceConfig?.speaker || 'zh_female_santongyongns_saturn_bigtts';
  }, [settings.voice]);

  // Get language speaker for translated content
  const getLanguageSpeaker = useCallback(() => {
    const langConfig = LANGUAGES.find(l => l.value === settings.language);
    return langConfig?.ttsSpeaker || 'zh_female_santongyongns_saturn_bigtts';
  }, [settings.language]);

  // Get speech recognition language
  const getSpeechLang = useCallback(() => {
    const dialectConfig = DIALECTS.find(d => d.value === settings.dialect);
    return dialectConfig?.speechLang || 'zh-CN';
  }, [settings.dialect]);

  // Play audio - properly manage lifecycle
  const playAudio = useCallback((url: string) => {
    // Stop any currently playing audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    const audio = new Audio(url);
    audioRef.current = audio;
    audio.play().catch((err) => {
      console.error('Audio playback failed:', err);
    });
    audio.onended = () => {
      audioRef.current = null;
    };
    audio.onerror = () => {
      audioRef.current = null;
    };
  }, []);

  // Initialize from localStorage
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    const saved = loadConversations();
    const savedSettings = loadSettings();
    setSettings(savedSettings);

    if (saved.length > 0) {
      setConversations(saved);
      setActiveConvId(saved[0].id);
      setMessages(saved[0].messages);
    } else {
      const newConv: Conversation = {
        id: generateId(),
        title: '新对话',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setConversations([newConv]);
      setActiveConvId(newConv.id);
    }

    // Show tutorial on first visit
    const tutorialSeen = localStorage.getItem(TUTORIAL_KEY);
    if (!tutorialSeen) {
      setShowTutorial(true);
    }
  }, []);

  // Auto scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Save conversations when they change
  useEffect(() => {
    if (initialized.current && conversations.length > 0) {
      saveConversations(conversations);
    }
  }, [conversations]);

  // Save settings when they change
  useEffect(() => {
    if (initialized.current) {
      saveSettings(settings);
    }
  }, [settings]);

  // Apply font size to document
  useEffect(() => {
    document.documentElement.style.setProperty('--base-font-size', `${settings.fontSize}px`);
  }, [settings.fontSize]);

  const updateActiveConversation = useCallback((updates: Partial<Conversation>) => {
    setConversations(prev => {
      const updated = prev.map(c =>
        c.id === activeConvId
          ? { ...c, ...updates, updatedAt: Date.now() }
          : c
      );
      return updated;
    });
  }, [activeConvId]);

  const handleNewConversation = useCallback(() => {
    const newConv: Conversation = {
      id: generateId(),
      title: '新对话',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations(prev => [newConv, ...prev]);
    setActiveConvId(newConv.id);
    setMessages([]);
    setShowConvList(false);
  }, []);

  const handleSelectConversation = useCallback((id: string) => {
    const conv = conversations.find(c => c.id === id);
    if (conv) {
      setActiveConvId(id);
      setMessages(conv.messages);
      setShowConvList(false);
    }
  }, [conversations]);

  const handleDeleteConversation = useCallback((id: string) => {
    setConversations(prev => {
      const filtered = prev.filter(c => c.id !== id);
      if (filtered.length === 0) {
        const newConv: Conversation = {
          id: generateId(),
          title: '新对话',
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        setActiveConvId(newConv.id);
        setMessages([]);
        return [newConv];
      }
      if (id === activeConvId) {
        setActiveConvId(filtered[0].id);
        setMessages(filtered[0].messages);
      }
      return filtered;
    });
  }, [activeConvId]);

  const handleSend = async (text: string) => {
    if (!text.trim() || isLoading) return;

    // Content safety check
    const safetyCheck = checkContentSafety(text);
    if (!safetyCheck.safe) {
      setContentWarning(safetyCheck.warning || '内容可能包含不当信息');
      setTimeout(() => setContentWarning(''), 5000);
      return;
    }

    const userMessage: Message = { id: generateId(), role: 'user', content: text };
    const assistantMessage: Message = { id: generateId(), role: 'assistant', content: '' };

    const newMessages = [...messages, userMessage, assistantMessage];
    setMessages(newMessages);
    setInputText('');
    setIsLoading(true);
    setContentWarning('');

    // Update conversation title if first message
    const activeConv = conversations.find(c => c.id === activeConvId);
    if (activeConv && activeConv.messages.length === 0) {
      updateActiveConversation({
        title: text.slice(0, 20) + (text.length > 20 ? '...' : ''),
        messages: newMessages,
      });
    }

    try {
      // Build message history for LLM (include system prompt)
      const systemPrompt = buildSystemPrompt(settings.dialect);
      const historyMessages = messages
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .map(m => ({ role: m.role, content: m.content }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: systemPrompt },
            ...historyMessages,
            { role: 'user', content: text },
          ],
        }),
      });

      if (!response.ok) throw new Error('Chat API failed');
      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;
            try {
              const parsed = JSON.parse(data);
              accumulated += parsed.content || '';
              setMessages(prev => prev.map(m =>
                m.id === assistantMessage.id ? { ...m, content: accumulated } : m
              ));
            } catch {
              // skip
            }
          }
        }
      }

      // Generate TTS for the response
      if (accumulated) {
        try {
          const ttsResponse = await fetch('/api/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: accumulated, speaker: getCurrentSpeaker() }),
          });
          if (ttsResponse.ok) {
            const ttsData = await ttsResponse.json();
            if (ttsData.audioUrl) {
              setMessages(prev => prev.map(m =>
                m.id === assistantMessage.id ? { ...m, audioUrl: ttsData.audioUrl } : m
              ));
              // Auto-play audio
              playAudio(ttsData.audioUrl);
            }
          }
        } catch (ttsError) {
          console.error('TTS failed:', ttsError);
        }
      }

      // Translate if needed
      if (settings.language !== 'zh' && accumulated) {
        try {
          const translateResponse = await fetch('/api/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: accumulated, targetLanguage: settings.language }),
          });
          if (translateResponse.ok) {
            const translateData = await translateResponse.json();
            if (translateData.translated) {
              setMessages(prev => prev.map(m =>
                m.id === assistantMessage.id ? { ...m, translatedContent: translateData.translated } : m
              ));

              // Generate TTS for translated content
              try {
                const ttsLangResponse = await fetch('/api/tts', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ text: translateData.translated, speaker: getLanguageSpeaker() }),
                });
                if (ttsLangResponse.ok) {
                  const ttsLangData = await ttsLangResponse.json();
                  if (ttsLangData.audioUrl) {
                    setMessages(prev => prev.map(m =>
                      m.id === assistantMessage.id ? { ...m, translatedAudioUrl: ttsLangData.audioUrl } : m
                    ));
                  }
                }
              } catch (ttsError) {
                console.error('TTS for translation failed:', ttsError);
              }
            }
          }
        } catch (translateError) {
          console.error('Translation failed:', translateError);
        }
      }

      // Update conversation with final messages
      setMessages(prev => {
        const updatedConv = conversations.map(c =>
          c.id === activeConvId ? { ...c, messages: prev, updatedAt: Date.now() } : c
        );
        setConversations(updatedConv);
        return prev;
      });
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => prev.map(m =>
        m.id === assistantMessage.id ? { ...m, content: '抱歉，出了点小问题，请再说一次好吗？' } : m
      ));
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceResult = (text: string) => {
    if (text) {
      handleSend(text);
    }
  };

  const handleSettingsChange = (newSettings: AppSettings) => {
    setSettings(newSettings);
  };

  const handleCloseTutorial = () => {
    setShowTutorial(false);
    localStorage.setItem(TUTORIAL_KEY, 'true');
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--background)]">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 bg-white border-b border-[var(--border)] shadow-sm">
        <button
          onClick={() => setShowConvList(true)}
          className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
          title="历史对话"
        >
          <svg className="w-5 h-5 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-xl font-bold text-[var(--primary)]">声伴</h1>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowTutorial(true)}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
            title="使用教程"
          >
            <svg className="w-5 h-5 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
            title="设置"
          >
            <svg className="w-5 h-5 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
          <button
            onClick={handleNewConversation}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
            title="新建对话"
          >
            <svg className="w-5 h-5 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
          </button>
        </div>
      </header>

      {/* Content warning */}
      {contentWarning && (
        <div className="mx-4 mt-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-xl text-amber-700 text-sm">
          {contentWarning}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-20 h-20 rounded-full bg-[var(--primary)]/10 flex items-center justify-center mb-4">
              <svg className="w-10 h-10 text-[var(--primary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <h2 style={{ fontSize: `${settings.fontSize + 2}px` }} className="font-bold text-[var(--foreground)] mb-2">
              您好，我是声伴
            </h2>
            <p style={{ fontSize: `${settings.fontSize}px` }} className="text-[var(--muted-foreground)] max-w-xs">
              您的专属语音陪伴助手。想聊什么都可以，我在这儿陪着您。
            </p>
          </div>
        )}
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            onPlayAudio={playAudio}
            fontSize={settings.fontSize}
          />
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-[var(--border)] rounded-2xl px-4 py-3 shadow-sm">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-[var(--primary)]/40 rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-[var(--primary)]/40 rounded-full animate-bounce [animation-delay:0.1s]" />
                <span className="w-2 h-2 bg-[var(--primary)]/40 rounded-full animate-bounce [animation-delay:0.2s]" />
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Quick Actions */}
      <QuickActions
        onSelect={(text) => handleSend(text)}
        disabled={isLoading || isRecording}
      />

      {/* Input Area */}
      <div className="px-4 pb-4 pt-2 bg-white border-t border-[var(--border)]">
        <div className="flex items-center gap-3">
          <VoiceButton
            onResult={handleVoiceResult}
            onRecordingChange={setIsRecording}
            speechLang={getSpeechLang()}
          />
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend(inputText)}
              placeholder={isRecording ? '正在听您说话...' : '输入想说的话...'}
              disabled={isLoading || isRecording}
              style={{ fontSize: `${settings.fontSize}px` }}
              className="w-full px-4 py-3 bg-[var(--muted)]/30 border border-[var(--border)] rounded-2xl text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:border-[var(--primary)] transition-colors"
            />
          </div>
          <button
            onClick={() => handleSend(inputText)}
            disabled={!inputText.trim() || isLoading || isRecording}
            className="flex-shrink-0 w-12 h-12 rounded-full bg-[var(--primary)] text-white flex items-center justify-center hover:opacity-90 active:scale-95 transition-all disabled:opacity-40"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 19V5m0 0l-7 7m7-7l7 7" />
            </svg>
          </button>
        </div>
        {isRecording && (
          <p className="text-center text-sm text-[var(--primary)] mt-2 animate-pulse">
            正在听您说话，说完后再点一下麦克风...
          </p>
        )}
      </div>

      {/* Modals */}
      {showConvList && (
        <ConversationList
          conversations={conversations}
          activeId={activeConvId}
          onSelect={handleSelectConversation}
          onDelete={handleDeleteConversation}
          onNew={handleNewConversation}
          onClose={() => setShowConvList(false)}
        />
      )}
      {showSettings && (
        <SettingsPanel
          settings={settings}
          onChange={handleSettingsChange}
          onClose={() => setShowSettings(false)}
        />
      )}
      {showTutorial && (
        <TutorialModal onClose={handleCloseTutorial} />
      )}
    </div>
  );
}
