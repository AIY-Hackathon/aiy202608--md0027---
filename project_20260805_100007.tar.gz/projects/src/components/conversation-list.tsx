'use client';

import type { Conversation } from '@/lib/types';

interface ConversationListProps {
  conversations: Conversation[];
  activeId: string;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onNew: () => void;
  onClose: () => void;
}

export function ConversationList({
  conversations,
  activeId,
  onSelect,
  onDelete,
  onNew,
  onClose,
}: ConversationListProps) {
  const formatTime = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    if (isToday) {
      return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
    }
    return `${d.getMonth() + 1}/${d.getDate()}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />

      {/* Panel */}
      <div className="relative w-80 max-w-[85vw] bg-[var(--background)] h-full shadow-xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[var(--border)]">
          <h2 className="text-lg font-bold text-[var(--foreground)]">历史对话</h2>
          <div className="flex items-center gap-1">
            <button
              onClick={onNew}
              className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
              title="新建对话"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
              </svg>
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-[var(--muted)] transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {conversations.length === 0 ? (
            <p className="text-center text-[var(--muted-foreground)] py-8">暂无历史对话</p>
          ) : (
            conversations.map((conv) => (
              <div
                key={conv.id}
                className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                  conv.id === activeId
                    ? 'bg-[var(--secondary)] border border-[var(--primary)]/30'
                    : 'bg-white border border-[var(--border)] hover:border-[var(--primary)]/20'
                }`}
                onClick={() => { onSelect(conv.id); onClose(); }}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-base font-medium text-[var(--foreground)] truncate">
                    {conv.title}
                  </p>
                  <p className="text-sm text-[var(--muted-foreground)] mt-0.5">
                    {conv.messages.length} 条消息 · {formatTime(conv.updatedAt)}
                  </p>
                </div>
                {conversations.length > 1 && (
                  <button
                    onClick={(e) => { e.stopPropagation(); onDelete(conv.id); }}
                    className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-[var(--muted-foreground)] hover:text-red-500 hover:bg-red-50 transition-colors"
                    title="删除对话"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
