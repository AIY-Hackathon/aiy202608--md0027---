'use client';

import { useState, useCallback } from 'react';
import { TOPIC_GROUPS } from '@/lib/constants';

interface QuickActionsProps {
  onSelect: (text: string) => void;
  disabled?: boolean;
}

export function QuickActions({ onSelect, disabled }: QuickActionsProps) {
  const [groupIndex, setGroupIndex] = useState(0);
  const currentTopics = TOPIC_GROUPS[groupIndex % TOPIC_GROUPS.length];

  const handleRefresh = useCallback(() => {
    setGroupIndex((prev) => (prev + 1) % TOPIC_GROUPS.length);
  }, []);

  return (
    <div className="px-4 pb-2">
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm text-[var(--muted-foreground)]">点击下方，开始聊天：</p>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1 text-sm text-[var(--primary)] hover:text-[var(--primary)]/80 transition-colors px-2 py-1 rounded-lg hover:bg-[var(--secondary)]"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          换一批
        </button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {currentTopics.map((action) => (
          <button
            key={action.text}
            onClick={() => onSelect(action.text)}
            disabled={disabled}
            className="flex items-center gap-2 px-4 py-3 rounded-xl bg-white border border-[var(--border)] text-[var(--foreground)] text-base hover:bg-[var(--secondary)] hover:border-[var(--primary)]/30 active:scale-[0.98] transition-all shadow-sm text-left disabled:opacity-50"
          >
            <span className="text-xl">{action.icon}</span>
            <span className="leading-tight">{action.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
