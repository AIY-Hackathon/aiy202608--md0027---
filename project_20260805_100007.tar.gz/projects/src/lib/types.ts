export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  audioUrl?: string;
  translatedContent?: string;
  translatedAudioUrl?: string;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  dialect: string;
  language: string;
  voice: string;
  fontSize: number;
}

export type Dialect = {
  value: string;
  label: string;
  defaultSpeaker: string;
  promptHint: string;
  region: string;
  cultureHint: string;
  speechLang: string; // BCP-47 code for Web Speech API recognition
};

export type Voice = {
  value: string;
  label: string;
  speaker: string;
  desc: string;
};

export type Language = {
  value: string;
  label: string;
  ttsSpeaker: string;
  speechLang: string; // BCP-47 code for speech recognition
};
