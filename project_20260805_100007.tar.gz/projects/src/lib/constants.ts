import type { Dialect, Voice, Language } from './types';

// ===== Voices =====
export const VOICES: Voice[] = [
  { value: 'warm_female', label: '温柔女声', speaker: 'zh_female_santongyongns_saturn_bigtts', desc: '温柔亲切' },
  { value: 'sweet_female', label: '甜美女声', speaker: 'zh_female_xiaohe_uranus_bigtts', desc: '清甜自然' },
  { value: 'childcare_female', label: '童书女声', speaker: 'zh_female_xueayi_saturn_bigtts', desc: '像讲故事' },
  { value: 'steady_male', label: '沉稳男声', speaker: 'zh_male_taocheng_uranus_bigtts', desc: '浑厚稳重' },
  { value: 'warm_male', label: '温暖男声', speaker: 'zh_male_m191_uranus_bigtts', desc: '阳光温暖' },
  { value: 'elegant_male', label: '儒雅男声', speaker: 'zh_male_ruyayichen_saturn_bigtts', desc: '温文尔雅' },
];

// ===== Dialects with regional culture + speech recognition lang =====
export const DIALECTS: Dialect[] = [
  {
    value: 'mandarin',
    label: '普通话',
    defaultSpeaker: 'zh_female_santongyongns_saturn_bigtts',
    promptHint: '使用标准普通话回复。',
    region: '全国',
    cultureHint: '可以聊全国各地的文化、节日习俗、历史故事等。',
    speechLang: 'zh-CN',
  },
  {
    value: 'cantonese',
    label: '粤语',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请使用粤语口语风格回复，使用粤语常用词汇和表达方式，如"唔该""系""咗""嘅""好耐冇见"等。',
    region: '广东/广西/港澳',
    cultureHint: '自然融入岭南文化元素：早茶文化、粤剧、广东美食（肠粉/白切鸡/老火靓汤）、花市、龙舟、骑楼建筑、岭南音乐等。',
    speechLang: 'zh-HK',
  },
  {
    value: 'southeastern',
    label: '闽南语',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入闽南语风格用语，如"阮""咱""袂""甲""厝"等闽南特色词汇。',
    region: '福建/台湾/东南亚',
    cultureHint: '自然融入闽南文化元素：妈祖信仰、南音/歌仔戏、闽南建筑（红砖厝）、功夫茶文化、博饼习俗、海上丝路文化等。',
    speechLang: 'zh-TW',
  },
  {
    value: 'southwest',
    label: '四川话',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入四川/重庆方言风格，如"巴适""安逸""要得""莫得""摆龙门阵"等用语。',
    region: '四川/重庆/云南/贵州',
    cultureHint: '自然融入西南文化元素：川剧变脸、火锅文化、茶馆摆龙门阵、蜀绣、都江堰、川菜美食、盖碗茶等。',
    speechLang: 'zh-CN',
  },
  {
    value: 'northeast',
    label: '东北话',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入东北方言风格，如"老好了""贼拉""整""唠嗑""嘎嘎""得劲"等东北特色用语。',
    region: '辽宁/吉林/黑龙江',
    cultureHint: '自然融入东北文化元素：二人转、大秧歌、东北大炖菜、炕头文化、冰灯/雪乡、东北幽默、饺子文化等。',
    speechLang: 'zh-CN',
  },
  {
    value: 'shanghai',
    label: '上海话',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入上海话风格，如"侬""阿拉""老好""灵光""扎台型"等上海特色用语。',
    region: '上海/江浙',
    cultureHint: '自然融入海派文化元素：弄堂生活、沪剧、本帮菜（红烧肉/小笼包/生煎）、外滩、石库门、海派旗袍等。',
    speechLang: 'zh-CN',
  },
  {
    value: 'changsha',
    label: '长沙话',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入长沙/湖南方言风格，如"韵味""霸蛮""策""恰饭""好耍"等用语。',
    region: '湖南/长沙',
    cultureHint: '自然融入湖湘文化元素：湘剧、花鼓戏、湘菜美食（臭豆腐/糖油粑粑/小龙虾）、岳麓书院、橘子洲等。',
    speechLang: 'zh-CN',
  },
  {
    value: 'hakka',
    label: '客家话',
    defaultSpeaker: 'zh_female_xiaohe_uranus_bigtts',
    promptHint: '请在回复中融入客家话风格，如"汝""涯""好走""食饭""多谢"等客家特色用语。',
    region: '广东/江西/福建',
    cultureHint: '自然融入客家文化元素：客家山歌、土楼建筑、客家美食（酿豆腐/盐焗鸡/梅菜扣肉）、客家迁徙历史等。',
    speechLang: 'zh-CN',
  },
];

// ===== Languages with TTS + speech recognition =====
export const LANGUAGES: Language[] = [
  { value: 'zh', label: '中文', ttsSpeaker: 'zh_female_santongyongns_saturn_bigtts', speechLang: 'zh-CN' },
  { value: 'en', label: 'English', ttsSpeaker: 'zh_female_vv_uranus_bigtts', speechLang: 'en-US' },
  { value: 'ja', label: '日本語', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'ja-JP' },
  { value: 'ko', label: '한국어', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'ko-KR' },
  { value: 'ru', label: 'Русский', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'ru-RU' },
  { value: 'fr', label: 'Français', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'fr-FR' },
  { value: 'de', label: 'Deutsch', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'de-DE' },
  { value: 'es', label: 'Español', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'es-ES' },
  { value: 'ar', label: 'العربية', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'ar-SA' },
  { value: 'th', label: 'ภาษาไทย', ttsSpeaker: 'zh_female_xiaohe_uranus_bigtts', speechLang: 'th-TH' },
];

// ===== Topic Groups (7 groups x 4 topics = 28) =====
export const TOPIC_GROUPS = [
  [
    { text: '想聊聊以前的往事', icon: '🏠' },
    { text: '小时候最开心的事', icon: '🌟' },
    { text: '当年工作的那些事', icon: '🏭' },
    { text: '最难忘的一道家常菜', icon: '🍜' },
  ],
  [
    { text: '今天天气怎么样', icon: '☀️' },
    { text: '最近吃了什么好吃的', icon: '🥘' },
    { text: '聊聊养花种草的心得', icon: '🌸' },
    { text: '平时喜欢做什么消遣', icon: '🎯' },
  ],
  [
    { text: '给我讲个怀旧小故事', icon: '📖' },
    { text: '聊聊经典老歌', icon: '🎵' },
    { text: '说说以前的老电影', icon: '🎬' },
    { text: '讲讲传统节日的习俗', icon: '🏮' },
  ],
  [
    { text: '了解养老防诈骗知识', icon: '🛡️' },
    { text: '老年人手机使用小技巧', icon: '📱' },
    { text: '四季养生小常识', icon: '🍵' },
    { text: '居家安全注意事项', icon: '🏡' },
  ],
  [
    { text: '心情不太好，想找人说说话', icon: '💛' },
    { text: '有点想家了', icon: '🏠' },
    { text: '一个人待着有点无聊', icon: '😔' },
    { text: '想听听暖心的话', icon: '🌈' },
  ],
  [
    { text: '想分享一下人生经验', icon: '💡' },
    { text: '聊聊怎么保持好心态', icon: '😊' },
    { text: '说说最骄傲的一件事', icon: '🏆' },
    { text: '给年轻人一些建议', icon: '📝' },
  ],
  [
    { text: '聊聊钓鱼的经验', icon: '🎣' },
    { text: '说说下棋的趣事', icon: '♟️' },
    { text: '聊聊太极和养生操', icon: '🧘' },
    { text: '分享做菜拿手绝活', icon: '👨‍🍳' },
  ],
];

// ===== Content warning patterns =====
export const CONTENT_WARNING_PATTERNS = [
  /操你|你妈|草泥马|傻[逼比]|妈的|狗[日逼]|他妈的|fuck|shit|bitch/i,
  /色情|做爱|性交|裸体|性爱|约炮|嫖/i,
  /杀人|自杀|砍死|打死|弄死/i,
];

// ===== Tutorial steps =====
export const TUTORIAL_STEPS = [
  {
    title: '打字聊天',
    desc: '在下方输入框输入想说的话，点发送按钮即可和声伴聊天。',
    icon: '💬',
  },
  {
    title: '语音说话',
    desc: '点绿色的麦克风按钮，开始说话，说完再点一下，声伴会自动识别您说的话。',
    icon: '🎤',
  },
  {
    title: '听声伴说话',
    desc: '声伴每次回复都会自动播放语音。也可以点消息下方的"播放语音"按钮再听一遍。',
    icon: '🔊',
  },
  {
    title: '快捷话题',
    desc: '不知道聊什么？点消息下方的话题按钮，一键开始聊天。点"换一批"看更多话题。',
    icon: '💡',
  },
  {
    title: '新建对话',
    desc: '点右上角的加号按钮可以开始一段新对话，旧对话会自动保存。',
    icon: '➕',
  },
  {
    title: '设置调整',
    desc: '点右上角齿轮按钮，可以切换声音、方言、语言，还能调节字体大小。',
    icon: '⚙️',
  },
];
