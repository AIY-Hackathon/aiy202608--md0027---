import { CONTENT_WARNING_PATTERNS } from './constants';

export function checkContentSafety(text: string): { safe: boolean; warning: string } {
  for (const pattern of CONTENT_WARNING_PATTERNS) {
    if (pattern.test(text)) {
      return {
        safe: false,
        warning: '您发送的内容包含不当用语，请文明交流哦。',
      };
    }
  }
  return { safe: true, warning: '' };
}
