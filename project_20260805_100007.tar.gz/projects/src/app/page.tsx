import { ChatInterface } from '@/components/chat-interface';

export default function Home() {
  return (
    <main className="h-screen flex flex-col bg-[var(--background)]">
      <ChatInterface />
    </main>
  );
}
