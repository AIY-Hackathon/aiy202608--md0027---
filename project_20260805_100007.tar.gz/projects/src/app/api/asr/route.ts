import { NextRequest, NextResponse } from 'next/server';
import { ASRClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { audio: base64Data, format } = body;
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    if (!base64Data) {
      return NextResponse.json({ error: '缺少音频数据' }, { status: 400 });
    }

    const config = new Config();
    const client = new ASRClient(config, customHeaders);

    const result = await client.recognize({
      uid: `user_${Date.now()}`,
      base64Data,
    });

    return NextResponse.json({
      text: result.text,
      duration: result.duration,
    });
  } catch (error) {
    console.error('ASR API error:', error);
    return NextResponse.json(
      { error: '语音识别失败' },
      { status: 500 }
    );
  }
}
