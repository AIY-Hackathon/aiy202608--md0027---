import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { text, targetLanguage } = await request.json();
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    if (!text || !targetLanguage) {
      return NextResponse.json({ error: '缺少参数' }, { status: 400 });
    }

    if (targetLanguage === 'zh') {
      return NextResponse.json({ translated: text });
    }

    const langNames: Record<string, string> = {
      en: 'English',
      ja: 'Japanese',
      ko: 'Korean',
      ru: 'Russian',
    };

    const langName = langNames[targetLanguage] || targetLanguage;

    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const messages: Array<{ role: 'system' | 'user'; content: string }> = [
      {
        role: 'system' as const,
        content: `You are a translator. Translate the following Chinese text to ${langName}. Only output the translation, nothing else. Keep the warm, conversational tone.`,
      },
      { role: 'user' as const, content: text },
    ];

    const response = await client.invoke(messages, {
      model: 'doubao-seed-2-0-mini-260215',
      temperature: 0.3,
    });

    return NextResponse.json({ translated: response.content });
  } catch (error) {
    console.error('Translate API error:', error);
    return NextResponse.json({ error: '翻译失败' }, { status: 500 });
  }
}
