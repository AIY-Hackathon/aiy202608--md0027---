import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '声伴 - 温暖的语音陪伴',
  description: '专为老年人打造的语音陪伴助手，陪您聊天、听您讲故事、为您解闷',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
