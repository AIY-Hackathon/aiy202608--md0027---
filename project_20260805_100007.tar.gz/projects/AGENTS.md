# AGENTS.md - 声伴项目

## 项目概览
"声伴"是专为老年人打造的温暖语音陪伴助手，基于 Next.js 16 + TypeScript 构建。

## 技术栈
- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI**: shadcn/ui + Tailwind CSS 4
- **AI**: coze-coding-dev-sdk (LLM + TTS + ASR)

## 目录结构
```
src/
├── app/
│   ├── api/
│   │   ├── chat/route.ts       # LLM 流式对话 API
│   │   ├── tts/route.ts        # 文字转语音 API
│   │   ├── asr/route.ts        # 语音转文字 API
│   │   └── translate/route.ts  # 多语种翻译 API
│   ├── layout.tsx              # 根布局
│   ├── page.tsx                # 主页面
│   └── globals.css             # 全局样式（含适老化配色）
├── components/
│   ├── chat-interface.tsx      # 核心聊天界面（含多会话管理）
│   ├── message-bubble.tsx      # 消息气泡（含翻译展示）
│   ├── quick-actions.tsx       # 快捷话题（7组28话题+换一批）
│   ├── voice-button.tsx        # 语音录制按钮
│   ├── conversation-list.tsx   # 历史对话列表（侧边栏）
│   └── settings-panel.tsx      # 设置面板（方言+语言）
└── lib/
    ├── types.ts                # 类型定义
    ├── constants.ts            # 方言/语言/话题常量
    ├── content-filter.ts       # 内容安全过滤
    └── utils.ts                # 工具函数
```

## 开发命令
- 安装依赖：`pnpm install`
- 开发：`pnpm dev`
- 构建：`pnpm build`
- 启动：`pnpm start`
- 类型检查：`pnpm ts-check`
- 代码检查：`pnpm lint`

## 核心功能
1. **流式对话**：SSE 协议打字机效果，完整上下文多轮对话
2. **语音输入**：MediaRecorder 录音 → ASR 识别
3. **语音输出**：TTS 合成 → 自动播放，方言语音
4. **多会话管理**：新建/切换/删除对话，localStorage 持久化
5. **方言支持**：普通话/粤语/闽南语/西南官话/东北话
6. **多语种翻译**：中/英/日/韩/俄，翻译结果附在消息下方
7. **内容安全**：脏话/色情/暴力内容过滤提醒
8. **28个快捷话题**：7组分类，支持"换一批"
9. **共情对话**：深度共情、连贯记忆、减少重复、引导深入
10. **适老化设计**：大字体、暖色调、高对比度

## 设计规范
详见 `DESIGN.md`，核心要点：
- 基础字号 18px，行高 1.8
- 暖米白背景 #FFF8F0，暖橙主色 #E8825A
- 大按钮（最小 48px 高度），圆角 16px
- 柔和绿辅助色 #7FB685
